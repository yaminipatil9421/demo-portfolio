(() => {
  "use strict";
  const config = window.AKS_CONFIG || {};
  const menu = Array.isArray(window.AKS_MENU) ? window.AKS_MENU : [];
  const categories = ["All", "Hot Coffee", "Flavoured Cappuccino", "Frappe", "Flavoured Frappe", "Shakes", "Mocktails", "Add-ons"];
  const cart = new Map();
  const $ = (s, root=document) => root.querySelector(s);
  const money = n => new Intl.NumberFormat("en-IN", {style:"currency",currency:"INR",maximumFractionDigits:0}).format(n);
  const grid = $("#productGrid"), filters = $("#categoryFilters"), dock = $("#cartDock");
  let activeCategory = "All", toastTimer;

  // Business details are intentionally editable in config.js.
  $("#cafeAddress").textContent = config.address || "Address to be confirmed";
  $("#openingHours").textContent = config.openingHours || "Please contact the café for today’s hours";
  $("#cafePhone").textContent = config.phoneDisplay || "Contact number to be confirmed";
  $("#mapLink").href = config.mapUrl || "#visit";
  $("#mapLink").addEventListener("click", e => { if (!config.mapUrl) { e.preventDefault(); notify("The café’s map link will be added once confirmed."); }});
  const insta = config.instagramUrl || "#";
  $("#instagramLink").href = insta; $("#footerInstagram").href = insta;
  for (const link of [$("#instagramLink"), $("#footerInstagram")]) link.addEventListener("click", e => { if (!config.instagramUrl) { e.preventDefault(); notify("The official Instagram link will be added soon."); }});
  $("#year").textContent = new Date().getFullYear();
  $("#contactLink").href = config.whatsappNumber ? `https://wa.me/${config.whatsappNumber}` : "#menu";
  $("#contactLink").addEventListener("click", e => { if (!config.whatsappNumber) { e.preventDefault(); notify("WhatsApp contact will be enabled after the café number is added."); }});
  $("#floatingWhatsApp").addEventListener("click", () => {
    if (!validWhatsApp()) return notify("WhatsApp contact will be enabled after the café number is added.");
    window.open(`https://wa.me/${config.whatsappNumber}`, "_blank", "noopener");
  });

  function notify(message) {
    const toast = $("#toast"); toast.textContent = message; toast.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
  }
  function validWhatsApp() { return /^\d{10,15}$/.test(config.whatsappNumber || ""); }

  function renderFilters() {
    filters.innerHTML = "";
    const used = categories;
    used.forEach(category => {
      const b = document.createElement("button"); b.className = `category-chip${activeCategory===category?" active":""}`;
      b.textContent = category; b.type = "button"; b.setAttribute("aria-pressed", String(activeCategory===category));
      b.addEventListener("click", () => { activeCategory = category; renderFilters(); renderMenu(); });
      filters.appendChild(b);
    });
  }
  function renderMenu() {
    const products = menu.filter(p => activeCategory === "All" || p.category === activeCategory);
    $("#menuCount").textContent = `${products.length} VERIFIED ${products.length===1?"ITEM":"ITEMS"}`;
    if (!products.length) {
      grid.innerHTML = `<div class="menu-empty"><span class="empty-icon">✳</span><p class="eyebrow">THE MENU IS BREWING</p><h3>Our full menu is<br><em>coming right up.</em></h3><p>We’re preparing the exact drinks and prices from the café’s original menu. Check back soon, or ask us at the counter.</p><a class="button button-outline-light" href="#visit">Visit the café <span>↗</span></a></div>`;
      return;
    }
    grid.innerHTML = "";
    products.forEach(p => {
      const card = document.createElement("article"); card.className = "product-card";
      const img = document.createElement("img"); img.src = p.image || "assets/menu/replace-with-item-photo.jpg"; img.alt = p.name; img.loading = "lazy"; img.onerror = () => { img.style.display = "none"; };
      const info = document.createElement("div"); info.className = "product-info";
      const meta = document.createElement("div"); meta.className = "product-meta";
      const title = document.createElement("h3"); title.textContent = p.name;
      const price = document.createElement("span"); price.className = "product-price"; price.textContent = money(p.price);
      meta.append(title, price);
      const desc = document.createElement("p"); desc.textContent = p.description || "";
      const add = document.createElement("button"); add.className = "add-button"; add.type = "button"; add.textContent = "ADD TO ORDER +";
      add.addEventListener("click", () => changeQty(p.id, 1));
      info.append(meta, desc, add); card.append(img, info); grid.append(card);
    });
  }
  function changeQty(id, delta) {
    const item = menu.find(p => p.id === id); if (!item) return;
    const next = (cart.get(id) || 0) + delta;
    if (next <= 0) cart.delete(id); else cart.set(id, next);
    renderCart(); notify(`${item.name} ${delta>0?"added to":"updated in"} your order.`);
  }
  function totals() {
    let count=0, total=0;
    for (const [id, qty] of cart) { const p=menu.find(x=>x.id===id); if(p){count+=qty;total+=p.price*qty;} }
    return {count,total};
  }
  function renderCart() {
    const {count,total}=totals(); dock.hidden = count===0;
    $("#cartItems").textContent=count; $("#cartTotal").textContent=money(total);
    if ($("#checkoutModal").classList.contains("open")) renderSummary();
  }
  function renderSummary() {
    const box=$("#checkoutSummary"); box.innerHTML="";
    for (const [id,qty] of cart) {
      const p=menu.find(x=>x.id===id); if(!p) continue;
      const row=document.createElement("div"); row.className="summary-line";
      const name=document.createElement("span"); name.textContent=`${p.name} · ${money(p.price)} each`;
      const controls=document.createElement("span"); controls.className="qty-controls";
      const minus=document.createElement("button"); minus.type="button"; minus.textContent="−"; minus.setAttribute("aria-label",`Remove one ${p.name}`); minus.addEventListener("click",()=>changeQty(id,-1));
      const q=document.createElement("b"); q.textContent=qty;
      const plus=document.createElement("button"); plus.type="button"; plus.textContent="+"; plus.setAttribute("aria-label",`Add one ${p.name}`); plus.addEventListener("click",()=>changeQty(id,1));
      const lineTotal=document.createElement("b"); lineTotal.textContent=money(p.price*qty);
      controls.append(minus,q,plus); row.append(name,controls,lineTotal); box.append(row);
    }
    const total=document.createElement("div"); total.className="summary-line summary-total"; total.innerHTML="<span>Total</span>";
    const amount=document.createElement("strong"); amount.textContent=money(totals().total); total.append(amount); box.append(total);
  }
  function openCheckout() {
    if (!totals().count) return;
    renderSummary(); const modal=$("#checkoutModal"); modal.classList.add("open"); modal.setAttribute("aria-hidden","false");
    document.body.style.overflow="hidden"; $("#closeCheckout").focus();
  }
  function closeCheckout() {
    $("#checkoutModal").classList.remove("open"); $("#checkoutModal").setAttribute("aria-hidden","true"); document.body.style.overflow="";
  }
  $("#openCheckout").addEventListener("click", openCheckout);
  $("#closeCheckout").addEventListener("click", closeCheckout);
  $("#checkoutModal").addEventListener("click", e => { if(e.target.id==="checkoutModal") closeCheckout(); });
  document.addEventListener("keydown", e => { if(e.key==="Escape") closeCheckout(); });

  $("#checkoutForm").addEventListener("submit", e => {
    e.preventDefault();
    if (!cart.size) return notify("Your cart is empty.");
    if (!validWhatsApp()) return notify("Pre-order is not active yet. The café owner must add a valid WhatsApp number in config.js.");
    const data = new FormData(e.currentTarget);
    const lines = [...cart].map(([id,qty]) => { const p=menu.find(x=>x.id===id); return `${p.name} × ${qty} — ${money(p.price)} each = ${money(p.price*qty)}`; });
    const message = [
      `Hello ${config.cafeName || "AKS Coffee Essence"}! I'd like to request a pickup pre-order.`,
      "", "CUSTOMER DETAILS", `Name: ${data.get("customerName")}`, `Mobile: ${data.get("phone")}`,
      "", "ORDER", ...lines, `TOTAL: ${money(totals().total)}`,
      "", `Pickup date: ${data.get("pickupDate")}`, `Pickup time: ${data.get("pickupTime")}`,
      `Special instructions: ${data.get("notes") || "None"}`,
      "", "Please confirm availability and accept this order. I understand it is not confirmed until the café replies."
    ].join("\n");
    const url=`https://wa.me/${config.whatsappNumber}?text=${encodeURIComponent(message)}`;
    const win=window.open(url,"_blank");
    if (win) { win.opener = null; closeCheckout(); notify("WhatsApp opened with your order. Send the message to request confirmation."); }
    else notify("Please allow pop-ups to open WhatsApp and send your order.");
  });

  // Date cannot be earlier than today.
  const dateInput=$("#pickupDate"); const today=new Date(); const localToday=new Date(today.getTime()-today.getTimezoneOffset()*60000).toISOString().slice(0,10);
  dateInput.min=localToday; dateInput.value=localToday;

  // Mobile navigation
  const toggle=$("#menuToggle"), nav=$("#mainNav");
  toggle.addEventListener("click",()=>{const open=nav.classList.toggle("open");toggle.setAttribute("aria-expanded",String(open));toggle.setAttribute("aria-label",open?"Close navigation":"Open navigation");});
  nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");toggle.setAttribute("aria-expanded","false");}));

  // Scroll reveals and back-to-top.
  const revealEls=document.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add("in-view");observer.unobserve(entry.target);}}),{threshold:.12});
    revealEls.forEach(el=>observer.observe(el));
  } else revealEls.forEach(el=>el.classList.add("in-view"));
  const back=$("#backToTop");
  window.addEventListener("scroll",()=>back.classList.toggle("visible",window.scrollY>550),{passive:true});
  back.addEventListener("click",()=>window.scrollTo({top:0,behavior:"smooth"}));

  renderFilters(); renderMenu();
  window.addEventListener("load",()=>setTimeout(()=>$("#loader").classList.add("done"),350));
})();