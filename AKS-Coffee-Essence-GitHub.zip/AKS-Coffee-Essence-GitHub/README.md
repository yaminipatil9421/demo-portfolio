# AKS Coffee Essence — GitHub Pages Website

A responsive café website with a premium forest-green / cream / coffee-brown design. It includes a menu filter system, product cards, a shopping cart, pickup details and a WhatsApp order handoff.

## 1. Preview on your Mac

1. Download and unzip this project.
2. Open the extracted `AKS-Coffee-Essence-GitHub` folder.
3. Double-click `index.html` to preview it in your browser.
4. Keep all files and folders together. Do not upload only `index.html`.

## 2. Publish with GitHub Pages

### Create your repository

1. Sign in at https://github.com
2. Click the **+** icon at the top-right, then choose **New repository**.
3. Repository name: `aks-coffee-essence`
4. Choose **Public**.
5. Click **Create repository**.

### Upload the website

1. In the new repository, click **Add file → Upload files**.
2. Open the extracted website folder on your Mac.
3. Select and upload these items from inside the folder:
   - `index.html`
   - `styles.css`
   - `config.js`
   - `app.js`
   - `README.md`
   - `.nojekyll`
   - the `assets` folder
4. Wait for all files to finish uploading.
5. Scroll down and click **Commit changes**.

Important: `index.html` must be at the repository's top level, not inside another nested project folder.

### Turn on GitHub Pages

1. Open your repository's **Settings**.
2. Select **Pages** from the left-side menu.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch **main** and folder **/ (root)**.
5. Click **Save**.
6. Wait a minute or two, then refresh the Pages screen. GitHub will show your public website link.

Your URL will look similar to:

`https://YOUR-GITHUB-USERNAME.github.io/aks-coffee-essence/`

Anyone can open that public link without having a GitHub account.

## 3. Add the café's real menu and prices

The menu data is intentionally empty until the café's original menu can be read and verified. Do not publish guessed prices.

1. Open `config.js`.
2. Find `window.AKS_MENU = [];`.
3. Add one object per verified product. Example:

```js
window.AKS_MENU = [
  {
    id: "classic-cappuccino",
    name: "Classic Cappuccino",
    category: "Hot Coffee",
    price: 120,
    description: "Espresso with steamed milk and a soft foam finish.",
    image: "assets/menu/classic-cappuccino.jpg"
  }
];
```

4. Put the corresponding image file in `assets/menu/`.
5. Give every menu item a unique `id` and its own image path.
6. Save `config.js`, upload the updated file to GitHub, and commit the change. GitHub Pages will republish automatically.

Supported categories:
- Hot Coffee
- Flavoured Cappuccino
- Frappe
- Flavoured Frappe
- Shakes
- Mocktails
- Add-ons

## 4. Add WhatsApp and café details

Open `config.js` and update `window.AKS_CONFIG` using details approved by the café owner:

- `whatsappNumber`: official WhatsApp Business number, digits only, including country code. Example format: `919876543210`.
- `phoneDisplay`: public phone number.
- `address`: full street address.
- `mapUrl`: Google Maps share link.
- `instagramUrl`: official Instagram profile URL.
- `openingHours`: confirmed opening hours.

WhatsApp pickup ordering stays disabled until a valid number is entered. When enabled, the customer reviews the cart, enters their name/mobile/pickup date/time, then WhatsApp opens with a pre-filled message. The customer must press Send, and the café must accept the order. Opening WhatsApp does not mean the order is confirmed.

## 5. Important notes

- The Google Maps link supplied for AKS Coffee Essence has been added. The exact street address and pin should still be checked with the owner.
- Menu products/prices are not filled in because the readable original menu is not available in this project source.
- Main editorial photos and fonts are loaded from Unsplash and Google Fonts, so visitors need an internet connection to see them.
- This is a static website. It does not process online payments or save orders to a database.
