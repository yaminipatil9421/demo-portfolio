/*
  AKS COFFEE ESSENCE — BUSINESS SETTINGS
  Replace only with details confirmed by the café owner.
  WhatsApp number format: country code + number, digits only (India: 91XXXXXXXXXX).
*/
window.AKS_CONFIG = {
  cafeName: "AKS Coffee Essence",
  whatsappNumber: "", // Add the café's official WhatsApp Business number
  phoneDisplay: "Contact number to be confirmed",
  address: "Nashik, Maharashtra — exact address to be confirmed",
  mapUrl: "https://maps.app.goo.gl/5DjANsDrtXK2vLm29",
  instagramUrl: "", // Add the café's official Instagram profile
  openingHours: "Please contact the café for current opening hours"
};

/*
  VERIFIED MENU
  Add only item names and prices confirmed by the café owner.
  Put each menu photo in assets/menu/ and use its relative path below.
  Categories:
  Hot Coffee, Flavoured Cappuccino, Frappe, Flavoured Frappe,
  Shakes, Mocktails, Add-ons.

  Example:
  {
    id: "classic-cappuccino",
    name: "Classic Cappuccino",
    category: "Hot Coffee",
    price: 120,
    description: "Espresso with steamed milk and a soft foam finish.",
    image: "assets/menu/classic-cappuccino.jpg"
  }
*/
window.AKS_MENU = [];
